<?php

namespace Drupal\content_api\Controller;

use Drupal\Core\Link;
use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Drupal\Core\Url;
use Drupal\file\Entity\File;

/**
 * MitTicketController class.
 */
class ContentController extends ControllerBase {
  /**
   * Builds the list of domains and relevant entities.
   *
   * @param array $options
   *   A list of variables required to build editor or content pages.
   *
   * @see contentlist()
   *
   * @return array
   *   A Drupal page build array.
   */
  
  public function store() {

  $module_handler = \Drupal::service('module_handler');
  $module_path = $module_handler->getModule('content_api')->getPath();
  $content_log = Url::fromUri('base:' . $module_path . '/asset/Sample_row.csv')->toString();
  $host = \Drupal::request()->getSchemeAndHttpHost();
  $content_log = $host.$content_log;

   if (($handle    =   fopen($content_log, "r")) !== FALSE) {
       $n          =   1;
       while (($row    =   fgetcsv($handle)) !== FALSE) {
         // echo $test = "<p> $n fields in line  <br /></p>\n";
           if($n>1) {
                if(is_numeric($row[0])) { 
                        $node = \Drupal\node\Entity\Node::load($row[0]);
                        if(!empty($node))  {
                            $node->set("title", $row[1]);
                            $node->set("body", $row[2]);
                            $node->set("status", $row[3]);
                        }
                        else {
                          $node = Node::create([
                            'type'       => 'custom',
                            'title'      => $row[1],     
                            'body'       => $row[2],      
                            'status'     => $row[3],  
                            'uid' => 1,
                          ]);
                       }
                       $node->save();
                }
          }
          $n++;
       }
       fclose($handle);
   }

    return [
			'#title' => ' content API',
			'#markup' => 'sucessfully update',
			];
  }


}